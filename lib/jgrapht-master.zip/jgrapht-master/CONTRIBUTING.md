Thanks for your interest in improving JGraphT.:+1::tada:

Before preparing your first pull request, please take a look at our
[guidelines wiki page](https://github.com/jgrapht/jgrapht/wiki/Contributor-Guidelines).

