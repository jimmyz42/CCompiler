/**
 * Experimental package with graph coloring algorithms.
 */
package org.jgrapht.experimental.alg.color;
