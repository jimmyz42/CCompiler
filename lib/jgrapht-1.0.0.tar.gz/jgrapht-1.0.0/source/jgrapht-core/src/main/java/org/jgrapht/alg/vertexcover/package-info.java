/**
 * Vertex cover algorithms.
 */
package org.jgrapht.alg.vertexcover;
